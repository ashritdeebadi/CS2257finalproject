import json
import boto3 
import time
import os

def lambda_handler(event, context):
    # TODO implement
    configPath = os.environ['LAMBDA_TASK_ROOT'] + "/apigw.html"
    s = open(configPath).read()
    return s
