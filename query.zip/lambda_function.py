import json
import time
import boto3

from pymongo import MongoClient


    
client = MongoClient("mongodb://ashrit:123@3.87.191.219/youtubedb")
db = client["youtubedb"]
collection = db.youtubestat



def mongo_query(event):
    
    if event['query'] =='q1':
        #query: user retrieves most popular category for each country for that date  
        start = time.time()
        date=str('17.01.12')
        q1=list(collection.aggregate([ 
            {
                "$match": {"trending_date" :{"$eq":"{}".format(date)}}
            },
            
             {  '$group': {              
                     "_id": {                 
                         #'date':"$trending_date",                 
                         'country':"$country",                 
                         'category_id':"$category_id"                     
                             },
                     "views": {                  
                         '$sum': "$views"
                     }                     
                 }     
             },
             
             {
                 '$sort':{
                     #"_id.date":1,
                     "_id.country":1,
                     "views":-1
                    }
             },
            
            
            {
          "$group": {
            "_id": {
              "country": "$_id.country"
            },
            "categories": {
              "$push": {  "category_id": "$_id.category_id", "count": "$views" }
            }
          }
        }
            ,
            {
                '$project': {
                    'top': { 
                        '$slice': ['$categories', 1]
                    }
                }
            }
        
         ]))
         
        d = {date: {}}
        for each in q1:
            d[date][each['_id']['country']] = each['top']
        end = time.time()
        return d, end-start
        
        
        
    elif event['query'] =='q2':
        
        #2. Find the top 10 videos with highest likes each day.
        start = time.time()
        q2=list(collection.aggregate([    
             {  '$group': {              
                     "_id": {                 
                         'date':"$trending_date",                 
                         'country':"$country",                 
                         'title':"$title"                     
                             },
                     "likes": {                  
                         '$sum': "$likes"
                     }                     
                 }     
             },
             
             {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1,
                     "likes":-1
                    }
             },
            
            
            {
          "$group": {
            "_id": {
                'date':"$_id.date",
                "country": "$_id.country"
            },
            "categories": {
              "$push": {  "title": "$_id.title", "count": "$likes" }
            }
          }
        }
            ,
            {
                '$project': {
                    'top': { 
                        '$slice': ['$categories', 10]
                    }
                }
            },
            {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1
                    }
             }
        
         ], allowDiskUse=True))
        end = time.time() 
        d = {}
        for each in q2:
            if each['_id']['date'] not in d:
                d[each['_id']['date']] = {}
            if 'country' in each['_id']:
                d[each['_id']['date']][each['_id']['country']] = each['top']
            else:
                d[each['_id']['date']]['None'] = each['top']
                
        return d, end-start
        
        
    elif event['query'] =='q3':
        
        #3. Find the top 10 videos with highest dislikes each day.
        start = time.time()
        q3=list(collection.aggregate([    
             {  '$group': {              
                     "_id": {                 
                         'date':"$trending_date",                 
                         'country':"$country",                 
                         'title':"$title"                     
                             },
                     "dislikes": {                  
                         '$sum': "$dislikes"
                     }                     
                 }     
             },
             
             {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1,
                     "dislikes":-1
                    }
             },
            
            
            {
          "$group": {
            "_id": {
                'date':"$_id.date",
                "country": "$_id.country"
            },
            "categories": {
              "$push": {  "title": "$_id.title", "count": "$dislikes" }
            }
          }
        }
            ,
            {
                '$project': {
                    'top': { 
                        '$slice': ['$categories', 10]
                    }
                }
            },
            {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1
                    }
             }
        
         ], allowDiskUse=True))
        end = time.time()
        d = {}
        for each in q3:
            if each['_id']['date'] not in d:
                d[each['_id']['date']] = {}
            if 'country' in each['_id']:
                d[each['_id']['date']][each['_id']['country']] = each['top']
            else:
                d[each['_id']['date']]['None'] = each['top']
                
        return d, end-start
        
    elif event['query'] =='q4':
        #4. Find the top 10 videos with highest comment_count.
        start = time.time()
        q4=list(collection.aggregate([    
             {  '$group': {              
                     "_id": {                 
                         'date':"$trending_date",                 
                         'country':"$country",                 
                         'title':"$title"                     
                             },
                     "comment_count": {                  
                         '$sum': "$comment_count"
                     }                     
                 }     
             },
             
             {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1,
                     "comment_count":-1
                    }
             },
            
            
            {
          "$group": {
            "_id": {
                'date':"$_id.date",
                "country": "$_id.country"
            },
            "categories": {
              "$push": {  "title": "$_id.title", "count": "$comment_count" }
            }
          }
        }
            ,
            {
                '$project': {
                    'top': { 
                        '$slice': ['$categories', 10]
                    }
                }
            },
            {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1
                    }
             }
        
         ], allowDiskUse=True))
        end = time.time()
        d = {}
        for each in q4:
            if each['_id']['date'] not in d:
                d[each['_id']['date']] = {}
            if 'country' in each['_id']:
                d[each['_id']['date']][each['_id']['country']] = each['top']
            else:
                d[each['_id']['date']]['None'] = each['top']
                
        return d, end-start
    
    elif event['query'] =='q5':
        
        #4. Find the top 10  engaging videos.
        start = time.time()
        q5=list(collection.aggregate([    
             {  '$group': {              
                     "_id": {                 
                         'date':"$trending_date",                 
                         'country':"$country",                 
                         'title':"$title"                     
                             },
                     "views": {                  
                         '$sum': "$views"
                     } ,
                     "likes": {                  
                             '$sum': "$likes"
                         },
                 
                     "dislikes": {                  
                             '$sum': "$dislikes"
                         } ,
                 "comments" :{
                     '$sum': "$comment_count"
                 }
                 
                 }     
             },
            
            {
                
         '$addFields':{
           'interaction': { '$sum': ["$likes", "$dislikes","$comments"] }
         }
                
            },{
                
                       
         '$addFields':{
           'engagement' : {'$divide' : ['$interaction',"$views"]}
         }
            }
            ,
             
             {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1,
                     "engagement":-1
                    }
             },
            
            
            {
          "$group": {
            "_id": {
                'date':"$_id.date",
                "country": "$_id.country"
            },
              
            "categories": {
              "$push": {  "title": "$_id.title", "count": "$views" ,"likes" :"$likes" ,"dislikes" : "$dislikes" ,'engagement':'$engagement'}
            }
          }
        }
            ,
            {
                '$project': {
                    'top': { 
                        '$slice': ['$categories', 10]
                    }
                }
            },
            {
                 '$sort':{
                     "_id.date":1,
                     "_id.country":1
                    }
             }
         ], allowDiskUse=True))
        end = time.time()
        d = {}
        for each in q5:
            if each['_id']['date'] not in d:
                d[each['_id']['date']] = {}
            if 'country' in each['_id']:
                d[each['_id']['date']][each['_id']['country']] = each['top']
            else:
                d[each['_id']['date']]['None'] = each['top']
                
        return d, end-start
        # return q5

    
def wait_for_output(event):
    s3 = boto3.client('s3')
    while True:
        objs = s3.list_objects_v2(Bucket='dbsp-output',Prefix='result.out/')
        if objs['KeyCount'] == 0:
            time.sleep(2)
            continue
        else:
            for each in objs['Contents']:
                k = each['Key']
                if 'metadata' in k:
                    boto3.resource('s3').Object('dbsp-output',k).delete()
                    continue
                data = boto3.resource('s3').Object('dbsp-output',k).get()['Body'].read().decode('utf-8')
                boto3.resource('s3').Object('dbsp-output',k).delete()
                d = {}
                if int(event['query'][1]) in (2, 3, 4, 5):
                    for each in data.split('\n')[1:]:
                        x = each.split('","')
                        date = x[0][1:]
                        if len(x) < 2:
                            continue
                        if len(date) > 8 or ',' in date:
                            continue
                        if date not in d:
                            d[date] = {}
                        if x[1] not in d[date]:
                            d[date][x[1]] = []
                        d[date][x[1]].append({'title': x[2], 'count': x[3]})
                elif int(event['query'][1]) == 1:
                    d['17.01.12'] = {}
                    for each in data.split('\n')[1:]:
                        x = each.split(',')
                        if len(x) > 1 and x[1] != '':
                            d['17.01.12'][x[1][1:-1]] = [{"category_id": x[2][1:-1], "count": x[3][1:-1]}]
                    print(d)
                return d
        

def hive_query(event):
    hive_query = ["""
    
   SELECT * FROM  (SELECT *, RANK() OVER (PARTITION BY trending_date, country ORDER BY Total_views DESC) AS row_number FROM (SELECT trending_date,country,category_id, SUM(views) as Total_views FROM "dbsp"."youtubestat" where trending_date = '17.01.12'  group by trending_date,country,category_id order by trending_date,country,Total_views DESC) ) WHERE row_number <= 1 order by trending_date,country, row_number ASC;

    """,
    
    """
    SELECT * FROM  (SELECT *, RANK() OVER (PARTITION BY trending_date, country ORDER BY Total_likes DESC) AS row_number FROM (SELECT trending_date,country,title, SUM(likes) as Total_likes FROM "dbsp"."youtubestat"  group by trending_date,country,title order by trending_date,country,Total_likes DESC) ) WHERE row_number <= 10 order by trending_date,country, Total_likes DESC;

    """,
    
    """
    
SELECT * FROM  (SELECT *, RANK() OVER (PARTITION BY trending_date, country ORDER BY Total_dislikes DESC) AS row_number FROM (SELECT trending_date,country,title, SUM(dislikes) as Total_dislikes FROM "dbsp"."youtubestat"  group by trending_date,country,title order by trending_date,country,Total_dislikes DESC) ) WHERE row_number <= 10 order by trending_date,country, Total_dislikes DESC;

    """,
    
    """
    
   
SELECT * FROM  (SELECT *, RANK() OVER (PARTITION BY trending_date, country ORDER BY Total_comments DESC) AS row_number FROM (SELECT trending_date,country,title, SUM(comment_count) as Total_comments FROM "dbsp"."youtubestat"  group by trending_date,country,title order by trending_date,country,Total_comments DESC) ) WHERE row_number <= 10 order by trending_date,country, Total_comments DESC;

    """,
    
    
    """
    
    SELECT * FROM  
  (SELECT *, RANK() OVER (PARTITION BY trending_date, country ORDER BY engag DESC) AS row_number FROM 
                
      (    SELECT  trending_date,country,title,   ((Total_comments  + likes+dislikes)/(CAST (views As DOUBLE) ) ) as engag  FROM  (SELECT trending_date,country,title, SUM(comment_count) as Total_comments, SUM(likes) as likes, SUM(dislikes) as dislikes, SUM(views) as views FROM "dbsp"."youtubestat"  group by trending_date,country,title order by trending_date,country,Total_comments DESC) 
               )
   
               )
               
               WHERE row_number <= 10 order by trending_date,country;
    
    """]
    athena = boto3.client('athena')
    q = hive_query[int(event['query'][1]) - 1]
    id = athena.start_query_execution(
    QueryString=q,
    QueryExecutionContext={
        'Database': 'dbsp'
    },
    ResultConfiguration={
        'OutputLocation': 's3://dbsp-output/result.out',
        },
    WorkGroup='primary'
    )['QueryExecutionId']
    
    
    return wait_for_output(event), athena.get_query_execution(QueryExecutionId=id)['QueryExecution']['Statistics']['TotalExecutionTimeInMillis']/1000
    
    
def lambda_handler(event, context):

    
    
    # TODO implement
    if event['type'] == 'mongo':
        result, query_time = mongo_query(event)
        
    elif event['type'] == 'hive':
        result, query_time = hive_query(event)
        
    
    return {
        'statusCode': 200,
        'time': round(query_time, 2),
        'results': result
    }

    
    